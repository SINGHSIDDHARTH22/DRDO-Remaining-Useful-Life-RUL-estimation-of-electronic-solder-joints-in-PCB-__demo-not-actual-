# import numpy as np
# import os
# import pandas as pd
# import random
# import time

# random.seed(time.time())


# class RULDataSet(object):
#     def __init__(self,
#                  scaled_train_path='unit_number_RUL.csv',
#                  scaled_test_path='test_FD001_scaled_selected.csv',
#                  knee_point_path='knee_point_list.csv',
#                  num_steps=10,
#                  test_ratio=0.1
#                  ):

#         self.num_steps = num_steps
#         print("num_steps:",self.num_steps)
#         self.test_ratio = test_ratio
#         #unit_DataFrame=pd.read_csv(scaled_train_path,header=None,encoding='utf-8')
#         unit_number_RUL_scaled_list=self._read_unit_data(scaled_train_path)
#         unit_number_test_scaled_list=self._read_unit_data(scaled_test_path)
#         knee_point_DataFrame=pd.read_csv(knee_point_path,header=0,encoding='utf-8')
#         knee_point_np=knee_point_DataFrame.as_matrix()
#         self.train_X_list,self.train_y_list=self._generate_train_from_unit_list(
#                 num_steps,
#                 unit_number_RUL_scaled_list,
#                 knee_point_np)
#         self.final_test_X_list=self._generate_final_test_from_unit_list(
#                 num_steps,
#                 unit_number_test_scaled_list,
#                 knee_point_np)
        
#         train_X_tmp=self.train_X_list[0]
#         train_y_tmp=self.train_y_list[0]
#         for i in range(1,len(self.train_X_list)):
#             train_X_tmp=np.vstack((train_X_tmp,self.train_X_list[i]))
#             train_y_tmp=np.vstack((train_y_tmp,self.train_y_list[i]))
#         self.train_X=train_X_tmp
#         self.train_y=train_y_tmp
#         self.test_X_list,self.test_y_list=self._generate_test_from_unit_list(
#                 num_steps,
#                 unit_number_RUL_scaled_list,
#                 knee_point_np)
        
#         train_indices=list(range(len(self.train_X)))
#         random.shuffle(train_indices)
#         test_ratio=0.1
#         self.training_X=self.train_X[train_indices[0:int(len(train_indices)*(1-test_ratio))]]
#         self.training_y=self.train_y[train_indices[0:int(len(train_indices)*(1-test_ratio))]]
#         self.testing_X=self.train_X[train_indices[int(len(train_indices)*(1-test_ratio)):]]
#         self.testing_y=self.train_y[train_indices[int(len(train_indices)*(1-test_ratio)):]]
        
#         def _read_unit_data(self,path,isCut=True):
#             unit_DataFrame=pd.read_csv(path,header=None,encoding='utf-8')
#             unit_np=unit_DataFrame.as_matrix()  
#             unit_number_redundant=unit_np[:,0]  
#             unit_number=np.unique(unit_number_redundant)  
#             unit_nums=unit_number.shape[0] 

#             unit_number_list=[]
#             for i in range(0,unit_nums):
#                 condition_i=unit_np[:,0]==i+1
#                 unit_index_i=np.where(condition_i)
#                 unit_number_i_index=unit_index_i[0]
#                 unit_number_i=unit_np[unit_number_i_index,:]
#                 if(isCut):
#                     unit_number_i=unit_number_i[:,5:unit_number_i.shape[1]]
#                 unit_number_list.append(unit_number_i)
#             return unit_number_list


#     '''
#     def _generate_test(self,test_scaled_path,test_RUL_path,isCut=True):
#         test_unit_number_list=read_scaled_test_data(scaled_test_path,isCut=True)
#         # In[]
#         f=open('RUL_FD001.txt')
#         raw_txt=f.read()
#         print(raw_txt)
#         f.close()
#         str_list=raw_txt.split('\n')
#         #str_list_last=str_list[100]
#         #if(str_list_last==''):
#             #print("bingo")
#         test_RUL_list=[]
#         for i in range(len(str_list)):
#             if (str_list[i]!=''):
#                 test_RUL_list.append(int(str_list[i]))
#                 '''

#     def _generate_train_from_one_unit(self,multi_seq,TIMESTEPS=10):
#         X = []
#         Y = []
#         for i in range(len(multi_seq) - TIMESTEPS):
#             X.append(multi_seq[i:i + TIMESTEPS,0:multi_seq.shape[1]-1])
#             Y.append([multi_seq[i:i + TIMESTEPS,multi_seq.shape[1]-1]])
#         return np.array(X, dtype=np.float32), np.array(Y, dtype=np.float32)
    

#     def _generate_train_from_unit_list(self,num_steps,unit_number_RUL_scaled_list,knee_point_np):     
#         train_X_list=[]
#         train_Y_list=[]
#         for i in range(len(unit_number_RUL_scaled_list)):
#             # In
#             unit_number_i=unit_number_RUL_scaled_list[i]
#             unit_number_i_var=unit_number_i.var(axis=0)
#             # In
#             good_index_i=unit_number_i_var>-1
#             unit_number_i_good=unit_number_i[:,good_index_i]
#             # In
#             knee_point_i=knee_point_np[i,0]
#             # In
#             #unit_number_i_good=unit_number_i_good[knee_point_i:unit_number_i_good.shape[0],:]
#             unit_number_i_good=unit_number_i_good[0:unit_number_i_good.shape[0],:]
#             # In
#             train_X_i=[]
#             train_Y_i=[]
#             train_X_i,train_Y_i=self._generate_train_from_one_unit(unit_number_i_good,TIMESTEPS=self.num_steps)
#             #print("num_steps:",self.num_steps)
#             #print("train_Y_i.shape:",train_Y_i.shape, i)
#             train_Y_i_tmp=np.transpose(train_Y_i,[0,2,1])
#             #print("train_Y_i_tmp.shape:",train_Y_i_tmp.shape)
#             train_X_list.append(train_X_i)
#             train_Y_list.append(train_Y_i_tmp)
#         return train_X_list,train_Y_list

#     def _generate_test_from_one_unit(self,multi_seq,TIMESTEPS=30):
#         X = []
#         Y = []
        
#         num_blocks=len(multi_seq)//TIMESTEPS
#         for i in range(len(multi_seq)//TIMESTEPS):
#             X.append(multi_seq[len(multi_seq)-(num_blocks-i)*TIMESTEPS:len(multi_seq)-(num_blocks-i-1)*TIMESTEPS,0:multi_seq.shape[1]-1])
#             Y.append([multi_seq[len(multi_seq)-(num_blocks-i)*TIMESTEPS:len(multi_seq)-(num_blocks-i-1)*TIMESTEPS,multi_seq.shape[1]-1]])
#         return np.array(X, dtype=np.float32), np.array(Y, dtype=np.float32)
    

#     def _generate_test_from_unit_list(self,num_steps,unit_number_RUL_scaled_list,knee_point_np):     
#         test_X_list=[]
#         test_Y_list=[]
#         for i in range(len(unit_number_RUL_scaled_list)):
#             # In
#             unit_number_i=unit_number_RUL_scaled_list[i]
#             unit_number_i_var=unit_number_i.var(axis=0)
#             # In
#             good_index_i=unit_number_i_var>-1
#             unit_number_i_good=unit_number_i[:,good_index_i]
#             # In
#             knee_point_i=knee_point_np[i,0]
#             # In
#             #unit_number_i_good=unit_number_i_good[knee_point_i:unit_number_i_good.shape[0],:]
#             unit_number_i_good=unit_number_i_good[0:unit_number_i_good.shape[0],:]
#             # In
#             test_X_i=[]
#             test_Y_i=[]
#             test_X_i,test_Y_i=self._generate_test_from_one_unit(unit_number_i_good,TIMESTEPS=num_steps)
#             test_Y_i=np.transpose(test_Y_i,[0,2,1])
#             test_X_list.append(test_X_i)
#             test_Y_list.append(test_Y_i)
#         return test_X_list,test_Y_list



#     def _generate_final_test_from_one_unit(self,multi_seq,TIMESTEPS=10):
#         X = []
#         for i in range(len(multi_seq) - TIMESTEPS):
#             X.append(multi_seq[i:i + TIMESTEPS,0:multi_seq.shape[1]])

#         return np.array(X, dtype=np.float32)
#     def _generate_final_test_from_unit_list(self,num_steps,unit_number_RUL_scaled_list,knee_point_np):
#         train_X_list=[]
#         for i in range(len(unit_number_RUL_scaled_list)):
#             # In
#             unit_number_i=unit_number_RUL_scaled_list[i]
#             unit_number_i_var=unit_number_i.var(axis=0)
#             # In
#             good_index_i=unit_number_i_var>-1
#             unit_number_i_good=unit_number_i[:,good_index_i]
#             # In
#             knee_point_i=knee_point_np[i,0]
#             # In
#             #unit_number_i_good=unit_number_i_good[knee_point_i:unit_number_i_good.shape[0],:]
#             unit_number_i_good=unit_number_i_good[0:unit_number_i_good.shape[0],:]
#             # In
#             train_X_i=[]

#             train_X_i=self._generate_final_test_from_one_unit(unit_number_i_good,TIMESTEPS=self.num_steps)

#             train_X_list.append(train_X_i)

#         return train_X_list

#     def _prepare_data(self, seq):
#         # split into items of input_size
#         seq = [np.array(seq[i * self.input_size: (i + 1) * self.input_size])
#                for i in range(len(seq) // self.input_size)]

#         if self.normalized:
#             seq = [seq[0] / seq[0][0] - 1.0] + [
#                 curr / seq[i][-1] - 1.0 for i, curr in enumerate(seq[1:])]

#         # split into groups of num_steps
#         X = np.array([seq[i: i + self.num_steps] for i in range(len(seq) - self.num_steps)])
#         y = np.array([seq[i + self.num_steps] for i in range(len(seq) - self.num_steps)])

#         train_size = int(len(X) * (1.0 - self.test_ratio))
#         train_X, test_X = X[:train_size], X[train_size:]
#         train_y, test_y = y[:train_size], y[train_size:]
#         return train_X, train_y, test_X, test_y

#     def _generate_one_epoch(self, batch_size):
#         num_batches = int(len(self.train_X)) // batch_size
#         if batch_size * num_batches < len(self.train_X):
#             num_batches += 1

#         batch_indices = list(range(num_batches))
#         random.shuffle(batch_indices)
#         for j in batch_indices:
#             batch_X = self.train_X[j * batch_size: (j + 1) * batch_size]
#             batch_y = self.train_y[j * batch_size: (j + 1) * batch_size]
#             assert set(map(len, batch_X)) == {self.num_steps}
#             yield batch_X, batch_y

# if __name__=="__main__":
#     #unit_DataFrame=pd.read_csv(scaled_train_path,header=None,encoding='utf-8')
#     RUL_Data=RULDataSet()
#     train_X_list=RUL_Data.train_X_list
#     train_Y_list=RUL_Data.train_Y_list
import numpy as np
import pandas as pd
import random
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import time

random.seed(time.time())

class StrainDataSet(object):
    def __init__(self,
                 data_path='dataset.xlsx',
                 num_steps=10,
                 test_ratio=0.2
                 ):
        """
        Initializes the dataset for equivalent strain prediction.
        
        Args:
            data_path (str): Path to the dataset.
            num_steps (int): Number of steps for the LSTM time windows.
            test_ratio (float): Fraction of data to be used for testing.
        """
        self.num_steps = num_steps
        print("num_steps:", self.num_steps)
        self.test_ratio = test_ratio
        
        # Load dataset and scale data
        data = pd.read_excel(data_path)
        self.features, self.target = self._process_data(data)
        
        # Generate training and testing datasets
        self.train_X, self.train_y, self.test_X, self.test_y = self._split_and_prepare_data(self.features, self.target)

    def _process_data(self, data):
        """
        Process the dataset to extract relevant features and target.
        
        Args:
            data (DataFrame): The raw dataset.
        
        Returns:
            features (np.array): Scaled feature set.
            target (np.array): Target values (equivalent strain).
        """
        # Extract input features (X) and target (y)
        X = data[['Strain energy', 'Total deformation', 'max Shear strain']]
        y = data['Equivalent strain']
        
        # Normalize the features
        scaler = MinMaxScaler()
        X_scaled = scaler.fit_transform(X)
        
        return X_scaled, y.values

    def _generate_train_from_one_unit(self, multi_seq, TIMESTEPS=10):
        """
        Generates training data for a single sequence.
        
        Args:
            multi_seq (np.array): Input sequence data.
            TIMESTEPS (int): Number of steps for each window.
        
        Returns:
            X, Y (np.array): Input and output arrays.
        """
        X = []
        Y = []
        for i in range(len(multi_seq) - TIMESTEPS):
            X.append(multi_seq[i:i + TIMESTEPS, 0:multi_seq.shape[1]-1])
            Y.append([multi_seq[i:i + TIMESTEPS, multi_seq.shape[1]-1]])
        return np.array(X, dtype=np.float32), np.array(Y, dtype=np.float32)

    def _split_and_prepare_data(self, features, target):
        """
        Split the dataset into training and testing sets, and generate
        sequences of inputs and targets for LSTM.
        
        Args:
            features (np.array): The input feature set.
            target (np.array): The target values (equivalent strain).
        
        Returns:
            train_X, train_y, test_X, test_y (np.array): Prepared data arrays.
        """
        # Split into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=self.test_ratio, random_state=42)
        
        # Generate sequences for LSTM
        train_X, train_y = self._generate_train_from_one_unit(np.column_stack((X_train, y_train)), TIMESTEPS=self.num_steps)
        test_X, test_y = self._generate_train_from_one_unit(np.column_stack((X_test, y_test)), TIMESTEPS=self.num_steps)
        
        return train_X, train_y, test_X, test_y

    def _generate_one_epoch(self, batch_size):
        """
        Yields batches of training data.
        
        Args:
            batch_size (int): Size of each batch.
        
        Yields:
            batch_X, batch_y (np.array): Batched inputs and targets.
        """
        num_batches = len(self.train_X) // batch_size
        if batch_size * num_batches < len(self.train_X):
            num_batches += 1

        batch_indices = list(range(num_batches))
        random.shuffle(batch_indices)
        for j in batch_indices:
            batch_X = self.train_X[j * batch_size: (j + 1) * batch_size]
            batch_y = self.train_y[j * batch_size: (j + 1) * batch_size]
            yield batch_X, batch_y

if __name__ == "__main__":
    # Example usage of StrainDataSet class
    dataset_path = '/path/to/your/dataset.xlsx'  # Update with your actual file path
    strain_dataset = StrainDataSet(data_path=dataset_path, num_steps=10, test_ratio=0.2)

    # Access the prepared training and test data
    train_X = strain_dataset.train_X
    train_y = strain_dataset.train_y
    test_X = strain_dataset.test_X
    test_y = strain_dataset.test_y

    print(f"Train X shape: {train_X.shape}, Train y shape: {train_y.shape}")
    print(f"Test X shape: {test_X.shape}, Test y shape: {test_y.shape}")


    

    